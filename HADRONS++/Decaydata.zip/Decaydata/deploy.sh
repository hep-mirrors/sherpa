#!/bin/bash

if test "$(basename $PWD)" != "Decaydata"; then
    echo "Need to run in Decaydata/ directory."
    exit 1;
fi

cd ..

zip -r Decaydata.zip Decaydata/ --exclude Decaydata/.svn/\*
mv Decaydata.zip SHERPA/HADRONS++/

if test -e tmp.svn; then exit 1; fi
mv Decaydata/.svn tmp.svn
../branches/rel-2-2-5/AddOns/Dir2Db Decaydata/
mv tmp.svn Decaydata/.svn
mv Decaydata.db ../branches/rel-2-2-5/HADRONS++/

cd -
echo "Finished successfully."
